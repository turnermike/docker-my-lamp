<?php

echo 'testing abc123';

phpinfo();

?>